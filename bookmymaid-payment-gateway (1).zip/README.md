
# BookMyMaid - Payment Gateway Service

Spring Boot microservice that integrates with Razorpay to create payment orders for maid bookings.

## Features
- Create Razorpay order
- Save payment status
- Layered architecture

## Tech Stack
- Spring Boot
- JPA + MySQL
- Razorpay API

## Run Locally
1. Configure `application.yml`
2. Run using:
```bash
mvn spring-boot:run
```
