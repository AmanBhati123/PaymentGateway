
package com.bookmymaid.payment.repository;

import com.bookmymaid.payment.entity.PaymentStatus;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PaymentRepository extends JpaRepository<PaymentStatus, Long> {
}
