
package com.bookmymaid.payment.service;

import com.bookmymaid.payment.dto.PaymentRequestDto;
import com.bookmymaid.payment.entity.PaymentStatus;
import com.bookmymaid.payment.repository.PaymentRepository;
import com.razorpay.*;
import lombok.RequiredArgsConstructor;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class PaymentService {

    private final PaymentRepository paymentRepository;

    @Value("${razorpay.key}")
    private String razorpayKey;

    @Value("${razorpay.secret}")
    private String razorpaySecret;

    public String createOrder(PaymentRequestDto dto) throws RazorpayException {
        RazorpayClient client = new RazorpayClient(razorpayKey, razorpaySecret);

        JSONObject orderRequest = new JSONObject();
        orderRequest.put("amount", dto.getAmount() * 100);
        orderRequest.put("currency", "INR");
        orderRequest.put("receipt", "maid_rcpt_" + System.currentTimeMillis());

        Order order = client.Orders.create(orderRequest);

        PaymentStatus paymentStatus = new PaymentStatus();
        paymentStatus.setUserId(dto.getUserId());
        paymentStatus.setMaidId(dto.getMaidId());
        paymentStatus.setAmount(dto.getAmount());
        paymentStatus.setStatus("CREATED");
        paymentRepository.save(paymentStatus);

        return order.toString();
    }
}
