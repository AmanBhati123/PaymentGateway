
package com.bookmymaid.payment.dto;

import lombok.Data;

@Data
public class PaymentRequestDto {
    private int amount;
    private String userId;
    private String maidId;
}
