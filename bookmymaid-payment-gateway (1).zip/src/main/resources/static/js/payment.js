
document.getElementById("paymentForm").addEventListener("submit", function(e) {
    e.preventDefault();
    const userId = document.getElementById("userId").value;
    const maidId = document.getElementById("maidId").value;
    const amount = document.getElementById("amount").value;

    fetch("/api/payments/create-order", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ userId, maidId, amount })
    })
    .then(response => response.json())
    .then(data => {
        alert("Order Created: " + data.id);
        // Redirect to Razorpay payment page or open popup if required
    })
    .catch(error => {
        console.error("Error:", error);
        alert("Payment initiation failed.");
    });
});
